# Auto-Annotation-Using-YOLOv8-and-SAm
Auto Annotation for generating segmentation dataset using YOLOv8 &amp; SAM

Youtube video link: https://youtu.be/K_WYmsYhBEw

### Environment Setup:

  py -3.9  -m venv myvenv

  myvenv\Scripts\activate

  pip install ultralytics

![image](https://github.com/AarohiSingla/Auto-Annotation-Using-YOLOv8-and-SAm/assets/60029146/a4421cab-d19e-4cd6-9e3a-f62f14eba333)




